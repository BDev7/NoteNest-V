export default {
    providers: [
      {
        domain: "https://brief-swan-32.clerk.accounts.dev",
        applicationID: "convex",
      },
    ]
  };
/** @type {import('next').NextConfig} */
const nextConfig = {
    images : {
        domains : [
            "files.edgestore.dev"
        ]
    }
}

module.exports = nextConfig
